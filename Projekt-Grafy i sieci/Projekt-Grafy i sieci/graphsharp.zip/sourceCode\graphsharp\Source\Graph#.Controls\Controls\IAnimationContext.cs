﻿using System;

namespace GraphSharp.Controls
{
    public interface IAnimationContext
    {
        GraphCanvas GraphCanvas { get; }
    }
}