To make a release, just call the releaser.bat with the version number. It will create the bin, source and example zip files.

Example:

> releaser.bat 1.0


Important:
----------

You should have an svn client installed to your computer and it's bin directory should be added to your PATH environment
variable.
You must have install 7-zip (www.7-zip.org) to your C:\Program Files\7-zip directory.