﻿namespace GraphSharp.Algorithms.Layout.Compound
{
    public enum CompoundVertexInnerLayoutType
    {
        Automatic,
        ContextFree,
        Contextual,
        Fixed
    }
}
