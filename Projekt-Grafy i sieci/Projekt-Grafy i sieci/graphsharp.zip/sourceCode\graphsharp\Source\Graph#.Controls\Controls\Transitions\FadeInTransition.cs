﻿namespace GraphSharp.Controls
{
    public class FadeInTransition : FadeTransition
    {
        public FadeInTransition()
            : base( 0.0, 1.0 )
        {

        }
    }
}
