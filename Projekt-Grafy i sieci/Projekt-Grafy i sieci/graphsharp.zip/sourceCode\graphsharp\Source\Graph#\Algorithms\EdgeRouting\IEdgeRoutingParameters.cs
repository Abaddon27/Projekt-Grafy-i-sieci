﻿namespace GraphSharp.Algorithms.EdgeRouting
{
	public interface IEdgeRoutingParameters : IAlgorithmParameters
	{		
	}
}