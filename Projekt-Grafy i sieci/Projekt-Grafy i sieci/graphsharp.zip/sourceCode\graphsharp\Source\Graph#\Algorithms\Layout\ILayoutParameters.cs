﻿
namespace GraphSharp.Algorithms.Layout
{
	public interface ILayoutParameters : IAlgorithmParameters
	{
	}
}