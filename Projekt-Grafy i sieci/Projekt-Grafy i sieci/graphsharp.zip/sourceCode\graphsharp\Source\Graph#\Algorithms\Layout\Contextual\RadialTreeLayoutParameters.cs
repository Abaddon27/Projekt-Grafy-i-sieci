﻿namespace GraphSharp.Algorithms.Layout.Contextual
{
	public class RadialTreeLayoutParameters : LayoutParametersBase
	{
		
	}
}
