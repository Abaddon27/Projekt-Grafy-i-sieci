﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GraphSharp.Algorithms.Layout.Simple.Tree
{
    public enum SpanningTreeGeneration
    {
        BFS, 
        DFS
    }
}
