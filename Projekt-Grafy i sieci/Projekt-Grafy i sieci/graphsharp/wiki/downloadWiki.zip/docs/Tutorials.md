# Tutorials and videos

Tutorial (created by Sacha Barber): [http://sachabarber.net/?p=815](http://sachabarber.net/?p=815)

Simple usage scenario [http://www.youtube.com/watch?v=VTbuvkaPGxE](http://www.youtube.com/watch?v=VTbuvkaPGxE)
Data Visualization with Graph# [http://www.youtube.com/watch?v=agDPDzqB4o0&feature=related](http://www.youtube.com/watch?v=agDPDzqB4o0&feature=related)