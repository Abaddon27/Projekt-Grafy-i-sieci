# Graph#

**Project Description**
Graph# is a graph layout framework.
It contains some layout algorithms and a GraphLayout control for WPF applications.

[Architecture](Architecture) | [Tutorials](Tutorials) | [Roadmap](Roadmap) | **Documentation on the way** | **Silverlight support is on the way**

We depend on:
* Microsoft Code Contracts [http://msdn.microsoft.com/en-us/devlabs/dd491992.aspx](http://msdn.microsoft.com/en-us/devlabs/dd491992.aspx)
* QuickGraph [http://quickgraph.codeplex.com](http://quickgraph.codeplex.com)

![NDepend](Home_NDependLogo_PoweredBy.PNG|http://www.ndepend.com/)

**Supported layout algorithms**:
- Fruchterman - Reingold
- Kamada - Kawai
- ISOM
- LinLog
- Simple Tree layout
- Simple Circle layout
- **NEW** Sugiyama layout (Use the Efficient Sugiyama layout algorithm)
- **NEW** Compound graph layout (CompoundFDP algorithm)
- on the way:
	* radial tree
	* balloon tree
	* Orthogonal layout

**Supported overlap removal algorithms**:
- Force-Scan Algorithm

**Edge layout algorithms also supported!**
- on the way: orthogonal edge layout

**Highlight algorithms supported!**
- Simple highlight algorithm (highlight vertex/edge & neigbours)

**GraphLayout WPF control!**
- Can use all kinds of algorithms (layout, overlap removal, edge, highlight)
- Vertex dragging supported
- Templates for vertices and **edges** supported
- Mutable graph -> automatic relayout after the graph changes (burst mode: lot of modification but only 1 relayout)
- Async layout (background thread) supported
- Position changes are animated!

**Example application included!**

![](Home_GraphSharpSample.png)

**Example: Dependency Graph with LinLog layout using Graph#.Controls.GraphLayout control and Graph# lib**

![](Home_dependency-visualizer.png)

**IF YOU WANT TO TAKE PART IN THIS PROJECT, YOU'RE WELCOME! PLEASE CONTACT ME!**