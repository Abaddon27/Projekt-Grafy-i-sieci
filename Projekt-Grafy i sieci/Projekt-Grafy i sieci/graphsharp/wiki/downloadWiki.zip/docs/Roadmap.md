## v1.0 - Jun 1, 2009
* DONE
* bugfixing continues

## v1.5 - Sep 7, 2009
* Silverlight support (with Silverlight 3)
	* same algorithm library for SL and WPF
	* almost the same controls and behaviours

## 2.0 - Dec 31, 2009
* Multilevel algorithm support
* improved graph viewer (multilevel zooming feature for big graphs with more than 5000 vertices)