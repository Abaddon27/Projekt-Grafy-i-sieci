# Graph# Architecture

![](Architecture_GraphLayoutFWnew.png)